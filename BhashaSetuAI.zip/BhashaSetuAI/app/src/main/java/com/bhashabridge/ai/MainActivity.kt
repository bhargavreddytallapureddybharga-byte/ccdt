package com.bhashabridge.ai

import androidx.activity.ComponentActivity
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.view.ViewGroup
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.ComponentActivity
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import com.google.mlkit.nl.translate.DownloadConditions
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.Translator
import com.google.mlkit.nl.translate.TranslatorOptions
import java.util.Locale

class MainActivity : ComponentActivity(), TextToSpeech.OnInitListener {
    private lateinit var sourceText: EditText
    private lateinit var resultText: TextView
    private lateinit var languageSpinner: Spinner
    private lateinit var status: TextView
    private var tts: TextToSpeech? = null
    private var translator: Translator? = null
    private var selectedCode = "te"
    private var translated = ""

    private val languages = listOf(
        Language("Telugu", "te"), Language("Hindi", "hi"), Language("Tamil", "ta"),
        Language("Kannada", "kn"), Language("Malayalam", "ml"), Language("Bengali", "bn"),
        Language("Marathi", "mr"), Language("Gujarati", "gu"), Language("Punjabi", "pa"),
        Language("Urdu", "ur"), Language("Odia", "or"), Language("Assamese", "as")
    )

    private val pickImage = registerForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        if (uri != null) runOcr(uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        buildScreen()
    }

    private fun buildScreen() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 24, 24, 24)
            setBackgroundColor(0xFFF5F7FC.toInt())
        }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val title = TextView(this).apply {
            text = "భాషాసేతు AI\nమీ స్క్రీన్. మీ భాష."
            textSize = 25f; setTextColor(0xFF172554.toInt()); setPadding(0, 8, 0, 20)
        }
        content.addView(title)
        status = TextView(this).apply { text = "Offline-ready translation assistant"; textSize = 14f }
        content.addView(status)
        content.addView(label("Translate English into"))
        languageSpinner = Spinner(this)
        languageSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, languages.map { it.name })
        languageSpinner.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: android.view.View?, position: Int, id: Long) {
                selectedCode = languages[position].code
                closeTranslator()
                status.text = "Selected ${languages[position].name}. Download its model to use offline."
            }
        }
        content.addView(languageSpinner)
        content.addView(label("Text to translate"))
        sourceText = EditText(this).apply {
            hint = "Paste English text here…"
            minLines = 4; maxLines = 8; gravity = android.view.Gravity.TOP
            setText("Welcome! Please enter your details and select Submit.")
            setBackgroundColor(0xFFFFFFFF.toInt())
        }
        content.addView(sourceText, matchWidth())
        content.addView(actionButton("Translate offline") { translateText() })
        content.addView(actionButton("Download language model (internet needed once)") { downloadModel() })
        content.addView(actionButton("Extract text from screenshot / image") { pickImage.launch("image/*") })
        content.addView(label("Translation"))
        resultText = TextView(this).apply {
            text = "Your translation will appear here."; textSize = 20f
            setTextColor(0xFF172554.toInt()); setPadding(16, 18, 16, 18)
            setBackgroundColor(0xFFFFFFFF.toInt())
        }
        content.addView(resultText, matchWidth())
        content.addView(actionButton("🔊 Read translation aloud") {
            if (translated.isNotBlank()) tts?.speak(translated, TextToSpeech.QUEUE_FLUSH, null, "bhasha_voice")
            else toast("Translate some text first")
        })
        content.addView(actionButton("Show translation as floating overlay") { showOverlay() })
        content.addView(actionButton("Hide floating overlay") { stopService(Intent(this, OverlayService::class.java)) })
        content.addView(TextView(this).apply {
            text = "Privacy: OCR and translation run on this device. Image selection is user-initiated. Some protected app screens cannot be captured by Android."
            textSize = 12f; setTextColor(0xFF64748B.toInt()); setPadding(0, 20, 0, 12)
        })
        scroll.addView(content)
        root.addView(scroll)
        setContentView(root)
    }

    private fun label(value: String) = TextView(this).apply {
        text = value; textSize = 16f; setTextColor(0xFF334155.toInt()); setPadding(0, 18, 0, 8)
    }

    private fun matchWidth() = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)

    private fun actionButton(textValue: String, action: () -> Unit) = Button(this).apply {
        text = textValue; isAllCaps = false
        setOnClickListener { action() }
        val p = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        p.topMargin = 8; layoutParams = p
    }

    private fun getTranslator(): Translator {
        val target = TranslateLanguage.fromLanguageTag(selectedCode)
            ?: throw IllegalArgumentException("This language is not supported by the installed translation engine.")
        val options = TranslatorOptions.Builder().setSourceLanguage(TranslateLanguage.ENGLISH).setTargetLanguage(target).build()
        return Translation.getClient(options).also { translator = it }
    }

    private fun downloadModel() {
        try {
            status.text = "Downloading ${languages[languageSpinner.selectedItemPosition].name} model…"
            getTranslator().downloadModelIfNeeded(DownloadConditions.Builder().build())
                .addOnSuccessListener { status.text = "Language model is ready. Translation can now work offline."; toast("Model ready") }
                .addOnFailureListener { status.text = "Model download failed: ${it.localizedMessage}"; toast("Connect to internet and try again") }
        } catch (e: Exception) { toast(e.message ?: "Language unavailable") }
    }

    private fun translateText() {
        val input = sourceText.text.toString().trim()
        if (input.isEmpty()) { toast("Enter text first"); return }
        try {
            status.text = "Translating on this device…"
            getTranslator().translate(input)
                .addOnSuccessListener { translated = it; resultText.text = it; status.text = "Translation complete" }
                .addOnFailureListener { status.text = "Translation unavailable. Download this language model first."; toast(it.localizedMessage ?: "Translation failed") }
        } catch (e: Exception) { toast(e.message ?: "Translation error") }
    }

    private fun runOcr(uri: Uri) {
        status.text = "Recognising text in image…"
        try {
            val image = InputImage.fromFilePath(this, uri)
            TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS).process(image)
                .addOnSuccessListener { visionText ->
                    sourceText.setText(visionText.text)
                    status.text = if (visionText.text.isBlank()) "No readable text found" else "Text extracted. Tap Translate offline."
                }
                .addOnFailureListener { status.text = "OCR failed: ${it.localizedMessage}" }
        } catch (e: Exception) { status.text = "Cannot open image: ${e.localizedMessage}" }
    }

    private fun showOverlay() {
        if (!android.provider.Settings.canDrawOverlays(this)) {
            val intent = Intent(android.provider.Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            startActivity(intent)
            toast("Allow భాషాసేతు AI to display over other apps, then tap this button again")
            return
        }
        if (translated.isBlank()) { toast("Translate text first"); return }
        startService(Intent(this, OverlayService::class.java).putExtra(OverlayService.EXTRA_TEXT, translated))
    }

    override fun onInit(statusCode: Int) {
        if (statusCode == TextToSpeech.SUCCESS) tts?.language = Locale(selectedCode)
    }

    private fun closeTranslator() { translator?.close(); translator = null }
    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_LONG).show()
    override fun onDestroy() { closeTranslator(); tts?.stop(); tts?.shutdown(); super.onDestroy() }
    data class Language(val name: String, val code: String)
}
