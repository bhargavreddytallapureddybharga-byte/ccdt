package com.bhashabridge.ai

import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.WindowManager
import android.widget.TextView

/** Displays the latest translated text above other apps after the user grants overlay permission. */
class OverlayService : Service() {
    private var windowManager: WindowManager? = null
    private var view: TextView? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val message = intent?.getStringExtra(EXTRA_TEXT) ?: "భాషాసేతు AI"
        if (view == null) {
            windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
            view = TextView(this).apply {
                textSize = 17f
                setTextColor(0xFFFFFFFF.toInt())
                setBackgroundColor(0xEE172554.toInt())
                setPadding(28, 20, 28, 20)
                elevation = 12f
            }
            val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE
            val params = WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT
            ).apply { gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL; y = 100 }
            windowManager?.addView(view, params)
        }
        view?.text = message
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        if (view != null) windowManager?.removeView(view)
        view = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object { const val EXTRA_TEXT = "translated_text" }
}
