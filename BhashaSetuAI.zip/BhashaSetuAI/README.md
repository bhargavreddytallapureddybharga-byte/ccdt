# భాషాసేతు AI (BhashaSetu AI) – Android prototype

An offline-first Android prototype for English-to-Indian-language translation. It includes:
- On-device translation using Google ML Kit Translation
- On-device OCR from a user-selected screenshot/image
- Text-to-speech playback using the device's installed TTS voice
- Optional floating translation overlay
- Language selection for Telugu, Hindi, Tamil, Kannada, Malayalam, Bengali, Marathi, Gujarati, Punjabi, Urdu, Odia and Assamese (availability depends on ML Kit's language list and device TTS voices)

## Important scope note
This is a working starter prototype, not yet continuous automatic translation of every app screen. Android does not let ordinary apps silently read other apps' screens. This prototype lets the user select a screenshot/image, extracts text locally, translates it, and can show the result in an overlay. Some secure apps block screenshots. A later release can add user-approved MediaProjection capture with a foreground service and per-session capture controls.

## Requirements
- Android Studio (current stable)
- JDK 17
- Android SDK 35
- Internet for the first Gradle dependency sync and initial language-model download
- Android 6.0+ phone (API 23+)

## Build and run
1. Extract `BhashaSetuAI.zip`.
2. Open the `BhashaSetuAI` folder in Android Studio.
3. Allow Gradle sync and install any requested Android SDK components.
4. Connect an Android phone with USB debugging enabled, or start an emulator.
5. Press **Run**.
6. Select a target language.
7. Connect to the internet and tap **Download language model** once for each language you want offline.
8. Paste English text and tap **Translate offline**.
9. To OCR a screenshot, tap **Extract text from screenshot / image**, choose an image, then translate the extracted text.
10. To display the result over another app, tap **Show translation as floating overlay** and grant Android's “Display over other apps” permission.
11. Tap **Hide floating overlay** when finished.

## Offline behavior
After the selected translation model has been downloaded, translation runs on-device without a network connection. OCR also runs on-device. The initial Gradle build and model download require internet unless dependencies/models are separately provisioned. The Android TextToSpeech voice depends on installed system language data; download the desired voice in Android Settings for offline speech.

## Language support note
ML Kit's on-device translation API supports 50+ languages, but its exact language list can change. The app requests a language by BCP-47 tag; if the chosen language is not supported by the installed ML Kit version, model setup will fail. Non-English-to-non-English translations may use English as an intermediate language, which can affect quality.

## Privacy and safety
- No backend server or account is used by this prototype.
- OCR and translation are performed on-device.
- Image access is initiated by the user through Android's photo picker.
- The floating overlay requires explicit Android permission.
- Do not use translations as the sole basis for financial, medical, legal or emergency decisions.

## Current limitations
- Input/source language is English in this prototype.
- OCR is from a selected image/screenshot, not continuous capture of arbitrary apps.
- Overlay displays the translated text as a floating panel; it does not replace each original word in place.
- Protected/DRM/secure app screens may not be capturable.
- Speech output depends on the phone's installed TTS voices.

## Main files
- `app/src/main/java/com/bhashabridge/ai/MainActivity.kt` – UI, translation, OCR and speech
- `app/src/main/java/com/bhashabridge/ai/OverlayService.kt` – floating overlay
- `app/src/main/AndroidManifest.xml` – app and overlay declarations
- `app/build.gradle.kts` – ML Kit dependencies
